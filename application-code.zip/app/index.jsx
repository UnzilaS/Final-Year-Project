import { Link, useNavigation } from "expo-router";
import { initializeApp } from "firebase/app";
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  Pressable,
  ToastAndroid,
} from "react-native";
import Toast from "react-native-toast-message";
import { getDatabase, ref, onValue } from "firebase/database";

const login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [keepSignedIn, setKeepSignedIn] = useState(false);
  const navigation = useNavigation();

  const firebaseConfig = {
    apiKey: "AIzaSyARisU5Zx2fOB-aSk13-auv9sbl3kzPl6Y",
    authDomain: "gas-detection-a032a.firebaseapp.com",
    databaseURL: "https://gas-detection-a032a-default-rtdb.firebaseio.com",
    projectId: "gas-detection-a032a",
    storageBucket: "gas-detection-a032a.firebasestorage.app",
    messagingSenderId: "944557427949",
    appId: "1:944557427949:web:f4f5c45ff1b333fe02d0e4",
  };
  const app = initializeApp(firebaseConfig);
  const database = getDatabase(app);
  const firebaseEmail = ref(database, "email");
  const firebasePassword = ref(database, "password");
  const handleSubmit = () => {
    navigation.navigate("(tabs)");
    if (email === "" || password === "") {
      Toast.show({
        type: "error",
        text1: "Error",
        text2: "Please fill all fields",
        position: "bottom",
      });
    } else {
      onValue(firebaseEmail, (snapshot) => {
        const data = snapshot.val();
        if (data === email) {
          onValue(firebasePassword, (snapshot) => {
            const data = snapshot.val();
            if (data === password) {
              navigation.navigate("(tabs)");
            } else {
              Toast.show({
                type: "error",
                text1: "Error",
                text2: "Invalid Password",
                position: "bottom",
              });
            }
          });
        } else {
          Toast.show({
            type: "error",
            text1: "Error",
            text2: "Invalid Email",
            position: "bottom",
          });
        }
      });
    }
  };

  return (
    <View style={styles.container}>

      <Image source={require('../assets/images/logo.png')} style={{
        height: 100,
        width: 100,
        alignSelf: 'center', 
        resizeMode: 'contain'

      }} />

      <Text style={styles.title}>Login</Text>
      <Text style={styles.subtitle}>Welcome back to the app</Text>

      <TextInput
        style={styles.input}
        placeholder="Email Address"
        placeholderTextColor="#999"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#999"
        value={password}
        onChangeText={setPassword}
      />

      <Link href="forgotpassword" asChild>
        <Pressable style={styles.forgotPasswordButton}>
          <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
        </Pressable>
      </Link>

      {/* <Link href="(tabs)" asChild>
      <Pressable style={styles.loginButton} >
        <Text style={styles.loginButtonText}>Login</Text>
      </Pressable>
      </Link> */}

      <Pressable style={styles.loginButton} onPress={handleSubmit}>
        <Text style={styles.loginButtonText}>Login</Text>
      </Pressable>

      <Toast />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
    backgroundColor: "#FFF",
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#333",
  },
  subtitle: {
    fontSize: 18,
    color: "#666",
    marginVertical: 10,
  },
  input: {
    height: 50,
    borderColor: "#CCC",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 16,
    marginBottom: 20,
    color: "#333",
  },
  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  eyeIcon: {
    position: "absolute",
    right: 15,
    padding: 5,
  },
  eyeIconImage: {
    width: 25,
    height: 25,
  },
  forgotPasswordButton: {
    alignSelf: "flex-end",
    marginVertical: 10,
  },
  forgotPasswordText: {
    color: "#1E90FF",
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  checkbox: {
    marginRight: 10,
  },
  checkboxLabel: {
    fontSize: 16,
    color: "#333",
  },
  loginButton: {
    backgroundColor: "#1E90FF",
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  loginButtonText: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: "bold",
  },
  separatorContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 20,
  },
  separatorLine: {
    flex: 1,
    height: 1,
    backgroundColor: "#CCC",
  },
  separatorText: {
    marginHorizontal: 10,
    color: "#666",
  },
  googleButton: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#CCC",
    borderRadius: 10,
    padding: 15,
    justifyContent: "center",
  },
  googleLogo: {
    width: 24,
    height: 24,
    marginRight: 10,
  },
  googleButtonText: {
    color: "#333",
    fontSize: 16,
  },
  createAccountButton: {
    marginTop: 20,
    alignItems: "center",
  },
  createAccountText: {
    color: "#1E90FF",
    fontSize: 16,
  },
});

export default login;
