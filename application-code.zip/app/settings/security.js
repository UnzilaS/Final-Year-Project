import React from 'react';
import { View, Text, StyleSheet, Switch ,TouchableOpacity} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const Security = () => {
  const [isBiometricEnabled, setIsBiometricEnabled] = React.useState(false);
  const [isTwoFactorEnabled, setIsTwoFactorEnabled] = React.useState(false);

  return (
    
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Security</Text>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Enable Biometric Authentication</Text>
        <Switch
          value={isBiometricEnabled}
          onValueChange={setIsBiometricEnabled}
        />
      </View>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Enable Two-Factor Authentication</Text>
        <Switch
          value={isTwoFactorEnabled}
          onValueChange={setIsTwoFactorEnabled}
        />
      </View>

      <TouchableOpacity style={styles.changePasswordButton}>
        <Text style={styles.changePasswordButtonText}>Change Password</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingText: {
    fontSize: 16,
  },
  changePasswordButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  changePasswordButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Security;