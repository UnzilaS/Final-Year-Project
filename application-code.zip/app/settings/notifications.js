import React from 'react';
import { View, Text, StyleSheet, Switch,SafeAreaView } from 'react-native';

const Notifications = () => {
  const [isEmailEnabled, setIsEmailEnabled] = React.useState(true);
  const [isPushEnabled, setIsPushEnabled] = React.useState(true);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Notifications</Text>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Email Notifications</Text>
        <Switch
          value={isEmailEnabled}
          onValueChange={setIsEmailEnabled}
        />
      </View>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Push Notifications</Text>
        <Switch
          value={isPushEnabled}
          onValueChange={setIsPushEnabled}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingText: {
    fontSize: 16,
  },
});

export default Notifications;