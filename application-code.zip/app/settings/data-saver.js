import React from 'react';
import { View, Text, StyleSheet, Switch ,SafeAreaView} from 'react-native';

const DataSaver = () => {
  const [isDataSaverEnabled, setIsDataSaverEnabled] = React.useState(false);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Data Saver</Text>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Enable Data Saver</Text>
        <Switch
          value={isDataSaverEnabled}
          onValueChange={setIsDataSaverEnabled}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingText: {
    fontSize: 16,
  },
});

export default DataSaver;