import React from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity,SafeAreaView } from 'react-native';

const ReportProblem = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Report a Problem</Text>

      <TextInput
        style={styles.input}
        placeholder="Describe the issue"
        placeholderTextColor="#999"
        multiline
      />

      <TouchableOpacity style={styles.submitButton}>
        <Text style={styles.submitButtonText}>Submit</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
    fontSize: 16,
    height: 150,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ReportProblem;