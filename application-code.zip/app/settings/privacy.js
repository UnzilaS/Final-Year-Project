import React from 'react';
import { View, Text, StyleSheet, Switch,SafeAreaView } from 'react-native';

const Privacy = () => {
  const [isPrivateAccount, setIsPrivateAccount] = React.useState(false);
  const [isActivityStatusVisible, setIsActivityStatusVisible] = React.useState(true);

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Privacy</Text>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Private Account</Text>
        <Switch
          value={isPrivateAccount}
          onValueChange={setIsPrivateAccount}
        />
      </View>

      <View style={styles.settingItem}>
        <Text style={styles.settingText}>Show Activity Status</Text>
        <Switch
          value={isActivityStatusVisible}
          onValueChange={setIsActivityStatusVisible}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingText: {
    fontSize: 16,
  },
});

export default Privacy;