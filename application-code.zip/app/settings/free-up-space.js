import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity ,SafeAreaView} from 'react-native';

const FreeUpSpace = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Free Up Space</Text>

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Clear Cache</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Delete Unused Files</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default FreeUpSpace;