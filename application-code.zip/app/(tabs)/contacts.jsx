import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, FlatList, Linking, SafeAreaView, Alert } from 'react-native';

const initialCircles = [
  {
    id: '1',
    name: 'General',
    contacts: [
      { name: 'Alice', number: '123-456-7890' },
      { name: 'Bob', number: '987-654-3210' },
    ],
    iconColor: '#C4E17F',
  },
  {
    id: '2',
    name: 'Family',
    contacts: [
      { name: 'Charlie', number: '555-123-4567' },
      { name: 'David', number: '555-987-6543' },
      { name: 'Eve', number: '555-555-5555' },
    ],
    iconColor: '#A593E0',
  }
];

const Contacts = () => {
  const [circles, setCircles] = useState(initialCircles);
  const [expandedId, setExpandedId] = useState(null);
  const [newContactName, setNewContactName] = useState('');
  const [newContactNumber, setNewContactNumber] = useState('');
  const [selectedCircle, setSelectedCircle] = useState(null);

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
    setSelectedCircle(id);
  };

  const handleCall = (number) => {
    Linking.openURL(`tel:${number}`);
  };

  const addContact = () => {
    if (!newContactName || !newContactNumber) {
      Alert.alert('Error', 'Please enter both name and number');
      return;
    }

    setCircles((prevCircles) =>
      prevCircles.map((circle) =>
        circle.id === selectedCircle
          ? { ...circle, contacts: [...circle.contacts, { name: newContactName, number: newContactNumber }] }
          : circle
      )
    );
    setNewContactName('');
    setNewContactNumber('');
  };

  const renderItem = ({ item }) => (
    <View style={styles.circleItem}>
      <TouchableOpacity onPress={() => toggleExpand(item.id)}>
        <View style={styles.circleHeader}>
          <View style={[styles.circleIcon, { backgroundColor: item.iconColor }]} />
          <View style={styles.circleTextContainer}>
            <Text style={styles.circleName}>{item.name}</Text>
            <Text style={styles.circleContacts}>{item.contacts.length} Contacts</Text>
          </View>
        </View>
      </TouchableOpacity>
      {expandedId === item.id && (
        <>
          <FlatList
            data={item.contacts}
            renderItem={({ item: contact }) => (
              <TouchableOpacity onPress={() => handleCall(contact.number)}>
                <View style={styles.contactItem}>
                  <Text style={styles.contactName}>{contact.name}</Text>
                  <Text style={styles.contactNumber}>{contact.number}</Text>
                </View>
              </TouchableOpacity>
            )}
            keyExtractor={(contact) => contact.number}
          />
          <View style={styles.addContactContainer}>
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={newContactName}
              onChangeText={setNewContactName}
            />
            <TextInput
              style={styles.input}
              placeholder="Number"
              value={newContactNumber}
              keyboardType="phone-pad"
              onChangeText={setNewContactNumber}
            />
            <TouchableOpacity style={styles.addButton} onPress={addContact}>
              <Text style={styles.addButtonText}>Add</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
        <View style={styles.header}>
        <Text style={styles.headerTitle}>Emergency circle</Text>
      </View>
      <FlatList
        data={circles}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.circleList}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  container: { flex: 1, backgroundColor: '#F7F7F7' },
  circleList: { paddingHorizontal: 20 },
  circleItem: { backgroundColor: '#FFF', borderRadius: 10, padding: 15, marginBottom: 10, elevation: 2 },
  circleHeader: { flexDirection: 'row', alignItems: 'center' },
  circleIcon: { width: 40, height: 40, borderRadius: 20 },
  circleTextContainer: { marginLeft: 15 },
  circleName: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  circleContacts: { fontSize: 14, color: '#777' },
  contactItem: { padding: 10, borderTopWidth: 1, borderTopColor: '#eee' },
  contactName: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  contactNumber: { fontSize: 14, color: '#777' },
  addContactContainer: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  input: { flex: 1, height: 40, borderBottomWidth: 1, marginRight: 10, paddingHorizontal: 5 },
  addButton: { backgroundColor: '#28a745', padding: 10, borderRadius: 5 },
  addButtonText: { color: '#fff', fontWeight: 'bold' }
});

export default Contacts;
