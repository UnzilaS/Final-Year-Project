import { Link } from "expo-router";
import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";

const Settings = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        <Link href="/settings/edit-profile" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Edit profile</Text>
          </TouchableOpacity>
        </Link>
        <Link href="/settings/security" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Security</Text>
          </TouchableOpacity>
        </Link>
        <Link href="/settings/notifications" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Notifications</Text>
          </TouchableOpacity>
        </Link>
        <Link href="/settings/privacy" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Privacy</Text>
          </TouchableOpacity>
        </Link>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Support & About</Text>
        <Link href="/settings/help-support" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Help & Support</Text>
          </TouchableOpacity>
        </Link>
        <Link href="/settings/terms-policies" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Terms and Policies</Text>
          </TouchableOpacity>
        </Link>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Cache & cellular</Text>
        <Link href="/settings/free-up-space" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Free up space</Text>
          </TouchableOpacity>
        </Link>
        <Link href="/settings/data-saver" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Data Saver</Text>
          </TouchableOpacity>
        </Link>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Actions</Text>
        <Link href="/settings/report-problem" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Report a problem</Text>
          </TouchableOpacity>
        </Link>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Logout</Text>
        <Link href="login" asChild>
          <TouchableOpacity style={styles.item}>
            <Text style={styles.itemText}>Logout</Text>
          </TouchableOpacity>
        </Link>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 50,
  },
  section: {
    marginVertical: 10,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginVertical: 10,
  },
  item: {
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  itemText: {
    fontSize: 16,
  },
});

export default Settings;