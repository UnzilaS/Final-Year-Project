import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  FlatList,
} from "react-native";

const notificationsData = [
  {
    id: "1",
    type: "Warning",
    message: "Gas leak threshold is almost exceeded",
    time: "a few seconds ago",
    iconColor: "#FFA726", // Orange color for warning
  },
  {
    id: "2",
    type: "Danger",
    message: "Gas leak threshold was exceeded",
    time: "a day ago",
    iconColor: "#F44336", // Red color for danger
  },
  {
    id: "3",
    type: "Warning",
    message: "Gas leak threshold is almost exceeded",
    time: "a day ago",
    iconColor: "#FFA726", // Orange color for warning
  },
  {
    id: "4",
    type: "Danger",
    message: "Fire was detected.",
    time: "a day ago",
    iconColor: "#F44336", // Red color for danger
  },
  {
    id: "5",
    type: "Danger",
    message: "Fire was detected.",
    time: "a day ago",
    iconColor: "#F44336", // Red color for danger
  },
  {
    id: "6",
    type: "Danger",
    message: "Gas leak threshold was exceeded",
    time: "2 days ago",
    iconColor: "#F44336", // Red color for danger
  },
  {
    id: "7",
    type: "Info",
    message: "Settings updated successfully",
    time: "3 days ago",
    iconColor: "#3F51B5", // Blue color for info
  },
  {
    id: "8",
    type: "Danger",
    message: "Gas leak threshold was exceeded",
    time: "3 days ago",
    iconColor: "#F44336", // Red color for danger
  },
];

const notifications = () => {
  const renderItem = ({ item }) => (
    <View style={styles.notificationItem}>
      <View style={[styles.iconCircle, { backgroundColor: item.iconColor }]}>
        <Text style={styles.iconText}>!</Text>
      </View>
      <View style={styles.notificationTextContainer}>
        <Text >{item.message}</Text>
        <Text style={styles.notificationDetails}>
          {item.type} · {item.time}
        </Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Notifications</Text>
        <Text style={styles.headerSubtitle}>1 new notification</Text>
      </View>
     
        <FlatList
          data={notificationsData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.notificationList}
        />
      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F7F7F7",
  },
  header: {
    alignItems: "center",
    paddingTop: 40,
    paddingBottom: 10,
    backgroundColor: "#FFF",
    borderBottomWidth: 1,
    borderBottomColor: "#DDD",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  headerSubtitle: {
    fontSize: 16,
    color: "#666",
    marginBottom: 10,
  },

  notificationList: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  notificationItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFF",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    elevation: 2,
  },
  iconCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  iconText: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: "bold",
  },
  notificationTextContainer: {
    marginLeft: 15,
   
   
  },
  notificationMessage: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
  },
  notificationDetails: {
    fontSize: 14,
    color: "#777",
  },
 
});

export default notifications;
