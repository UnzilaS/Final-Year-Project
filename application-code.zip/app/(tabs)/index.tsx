import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Image, Alert, Button } from "react-native";
import { initializeApp } from "firebase/app";
import { getDatabase, ref, onValue } from "firebase/database";
import * as Notifications from 'expo-notifications';

const firebaseConfig = {
  apiKey: "AIzaSyARisU5Zx2fOB-aSk13-auv9sbl3kzPl6Y",
  authDomain: "gas-detection-a032a.firebaseapp.com",
  databaseURL: "https://gas-detection-a032a-default-rtdb.firebaseio.com",
  projectId: "gas-detection-a032a",
  storageBucket: "gas-detection-a032a.firebasestorage.app",
  messagingSenderId: "944557427949",
  appId: "1:944557427949:web:f4f5c45ff1b333fe02d0e4",
};

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

const requestNotificationPermission = async () => {
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') {
    Alert.alert('Permission denied', 'You need to enable notifications to receive them.');
    return false;
  }
  return true;
};

const sendPushNotification = async () => {
  const hasPermission = await requestNotificationPermission();
  if (!hasPermission) return;

  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Gas detected! 🚨',
      body: 'The gas valve has been automatically closed by the system for safety. Please check the area for leaks and ensure ventilation. If needed, contact emergency services. Stay safe!',
      sound: 'default',
    },
    trigger: null, // Send immediately
  });
};



const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

const dbRef = ref(database, "status"); // Replace with your actual path
const index = () => {
  const [data, setData] = useState(0);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    // Request permissions when the app loads
    requestNotificationPermission();
  }, []);

  useEffect(() => {
    const unsubscribe = onValue(dbRef, (snapshot) => {
      const data = snapshot.val();
      // console.log(snapshot);
      // console.log(data);
      setData(data);
    });

    return () => unsubscribe();
  }, []);
  const sendMessage = () => {
    console.log("Entered sendMessage function");
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "App 7bfe80e3f7e28c0224cef1fc14787b02-ccf00e55-5a7b-425b-a592-1b8f100474d3");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Accept", "application/json");

    const raw = JSON.stringify({
        "messages": [
            {
                "destinations": [{"to":"923162859459"}],
                "from": "447491163443",
                "text": "Gas detected! The gas valve has been automatically closed by the system for safety. Please check the area for leaks and ensure ventilation. If needed, contact emergency services. Stay safe!"
            }
        ]
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    fetch("https://d921gl.api.infobip.com/sms/2/text/advanced", requestOptions)
        .then((response) => response.text())
        .then((result) => {
            console.log(result);
            Alert.alert("Success", "Message sent successfully!");
        })
        .catch((error) => {
            console.error(error);
            Alert.alert("Error", "Failed to send message.");
        });
};

  const getStylesByData = (data: number) => {
    switch (data) {
      case 0: // Green (OK)
        return {
          container: { ...styles.container, backgroundColor: "#F7F7F7" },
          subtitle: { ...styles.subtitle, color: "#4ad66d" },
          wave: { ...styles.wave, backgroundColor: "#4ad66d", opacity: 0.1 },
          wave2: { ...styles.wave2, backgroundColor: "#4ad66d", opacity: 0.07 },
          wave3: { ...styles.wave3, backgroundColor: "#4ad66d", opacity: 0.04 },
          button: { ...styles.button, backgroundColor: "#4ad66d" },
        };
      case 1: // Yellow (Moderate) - More visible
        return {
          container: { ...styles.container, backgroundColor: "#FFF9E6" }, // Light yellow background
          subtitle: { ...styles.subtitle, color: "#FFCC00" }, // Brighter yellow text
          wave: { ...styles.wave, backgroundColor: "#FFCC00", opacity: 0.3 }, // Higher opacity for better visibility
          wave2: { ...styles.wave2, backgroundColor: "#FFCC00", opacity: 0.2 },
          wave3: { ...styles.wave3, backgroundColor: "#FFCC00", opacity: 0.1 },
          button: { ...styles.button, backgroundColor: "#FFCC00" }, // Brighter yellow button
        };
      case 2: // Red (High Gas Detection)
        sendMessage();
        sendPushNotification();
        return {
          container: { ...styles.container, backgroundColor: "#FFF0F0" },
          subtitle: { ...styles.subtitle, color: "#FF5722" },
          wave: { ...styles.wave, backgroundColor: "#FF5722", opacity: 0.1 },
          wave2: { ...styles.wave2, backgroundColor: "#FF5722", opacity: 0.07 },
          wave3: { ...styles.wave3, backgroundColor: "#FF5722", opacity: 0.04 },
          button: { ...styles.button, backgroundColor: "#FF5722" },
          closeWallButton: styles.closeWallButton, // Add styles for Close Wall button
        };
      default:
        return styles;
    }
  };

  // Get styles based on `data` value
  const dynamicStyles = getStylesByData(data);


 

  return (

    <View style={dynamicStyles.container}>
       <View >
        <Image
          source={require("../../assets/images/logo1.png")}
          style={{
            height: 50,
            width: 50,
            alignSelf: "center",
            resizeMode: "contain",
          }}
        />
      </View>
      <Text style={dynamicStyles.title}>Current Reading</Text>
      <Text style={dynamicStyles.subtitle}>
        Status: &nbsp;
        {data === 0 ? "OK" : data === 1 ? "Moderate" : "High Gas Detection"}
      </Text>

      <View style={styles.waveContainer}>
        <View style={dynamicStyles.wave} />
        <View style={[dynamicStyles.wave, dynamicStyles.wave2]} />
        <View style={[dynamicStyles.wave, dynamicStyles.wave3]} />
        <TouchableOpacity style={dynamicStyles.button} onPress={sendMessage}>
          <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 20 }}>
            {data}
          </Text>
        </TouchableOpacity>
      </View>
    

      

      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    paddingTop: 30,
    backgroundColor:'#fff'
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginHorizontal: 20,
    marginBottom: 20,
  },
  closeWallButton: {
    width: 150,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#FF5722", // Red color for the Close Wall button
    justifyContent: "center",
    alignItems: "center",
    marginVertical: 20,
  },
  waveContainer: {
    position: "relative",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  wave: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    opacity: 0.1,
  },
  wave2: {
    width: 250,
    height: 250,
    borderRadius: 125,
    opacity: 0.07,
  },
  wave3: {
    width: 300,
    height: 300,
    borderRadius: 150,
    opacity: 0.04,
  },
  button: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  navbar: {
    flexDirection: "row",
    backgroundColor: "#FFF",
    height: 60,
    width: "100%",
    justifyContent: "space-around",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#ccc",
  },
  navItem: {
    alignItems: "center",
  },
  navIcon: {
    width: 30,
    height: 30,
  },
  navText: {
    fontSize: 12,
    color: "#333",
  },
});

export default index;
