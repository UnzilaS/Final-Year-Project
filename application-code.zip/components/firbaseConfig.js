import { initializeApp } from "firebase/app";

// Optionally import the services that you want to use
// import {...} from "firebase/auth";
// import {...} from "firebase/database";
// import {...} from "firebase/firestore";
// import {...} from "firebase/functions";
// import {...} from "firebase/storage";

// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyARisU5Zx2fOB-aSk13-auv9sbl3kzPl6Y",
  authDomain: "gas-detection-a032a.firebaseapp.com",
  databaseURL: "https://gas-detection-a032a-default-rtdb.firebaseio.com",
  projectId: "gas-detection-a032a",
  storageBucket: "gas-detection-a032a.firebasestorage.app",
  messagingSenderId: "944557427949",
  appId: "1:944557427949:web:f4f5c45ff1b333fe02d0e4",
};

const app = initializeApp(firebaseConfig);
// For more information on how to access Firebase in your project,
// see the Firebase documentation: https://firebase.google.com/docs/web/setup#access-firebase
